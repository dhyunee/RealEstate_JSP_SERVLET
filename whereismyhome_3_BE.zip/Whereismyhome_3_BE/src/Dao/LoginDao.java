package Dao;

public interface LoginDao {

}
