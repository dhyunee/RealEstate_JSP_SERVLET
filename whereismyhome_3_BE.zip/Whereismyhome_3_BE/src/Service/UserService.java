package Service;

public interface UserService {

}
