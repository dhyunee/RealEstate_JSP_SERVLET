package Dto;

public class UserDto {

}
