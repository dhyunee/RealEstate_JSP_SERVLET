package Dao;

public interface UserDao {

}
