package Dao;

public interface MainDao {

}
