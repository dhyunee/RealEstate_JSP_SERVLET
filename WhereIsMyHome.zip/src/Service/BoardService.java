package Service;

import java.util.List;

import Dto.BoardDto;

public interface BoardService {
	int boardInsert(BoardDto dto);
	int boardDelete(int boardId);
	int boardUpdate(BoardDto dto);
	
	List<BoardDto> boardList(int limit, int offset);

	BoardDto boardDetail(int boardId, int userSeq);
}
