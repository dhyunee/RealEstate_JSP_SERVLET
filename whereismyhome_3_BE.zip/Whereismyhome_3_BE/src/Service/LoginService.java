package Service;

public interface LoginService {

}
