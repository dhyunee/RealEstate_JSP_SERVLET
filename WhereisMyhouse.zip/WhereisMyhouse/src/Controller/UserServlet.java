package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import Dao.UserDaoImpl;
import Dto.UserDto;
import Service.UserService;
import Service.UserServiceImpl;


@WebServlet("/user/*")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	UserService userService=UserServiceImpl.getInstance();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		HttpSession session=request.getSession();
		UserDto userDto=(UserDto)session.getAttribute("userDto");
		String contextPath = request.getContextPath();
		String path = request.getRequestURI().substring(contextPath.length());
		System.out.println(path);
		
		if(path=="/user/regist") {
			regist(request,response);
		}
		if(path=="/user/delete") {
			delete(request,response);
		}
	}
	protected void regist(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName=request.getParameter("userName");
		String userEmail=request.getParameter("userEmail");
		String userPassword=request.getParameter("userPassword");
		
		UserDto userDto =new UserDto();
		userDto.setUserName(userName);
		userDto.setUserEmail(userEmail);
		userDto.setUserPassword(userPassword);
		
		int ret=userService.userRegister(userDto);
		
		Gson gson=new Gson();
		JsonObject jsonobject=new JsonObject();

		if(ret==1) {
			jsonobject.addProperty("result","success");
		}else {
			jsonobject.addProperty("result","fail");
		}

		String jsonStr=gson.toJson(jsonobject);
		response.getWriter().write(jsonStr);
	}
	
	protected void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userEmail=request.getParameter("userEmail");
		String userPassword=request.getParameter("userPassword");
		
		UserDto userDto =new UserDto();

		userDto.setUserEmail(userEmail);
		userDto.setUserPassword(userPassword);
		
		int ret=userService.deleteUser(userDto);
		
		Gson gson=new Gson();
		JsonObject jsonobject=new JsonObject();

		if(ret==1) {
			jsonobject.addProperty("result","success");
		}else {
			jsonobject.addProperty("result","fail");
		}

		String jsonStr=gson.toJson(jsonobject);
		response.getWriter().write(jsonStr);
	}

}
