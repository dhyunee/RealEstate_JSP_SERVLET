package Dto;

public class MainDto {

}
