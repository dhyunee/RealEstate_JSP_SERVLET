package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBManager.DBManager;
import Dto.DongCodeDto;
import Dto.GugunCodeDto;
import Dto.MainDto;
import Dto.SidoCodeDto;

public class MainDaoImpl implements MainDao {
	private static MainDaoImpl instance = new MainDaoImpl();
	private DBManager util = DBManager.getInstance();
	private MainDaoImpl() {
	}

	public static MainDaoImpl getInstance() {
		return instance;
	}

	@Override
	public List<GugunCodeDto> getGugun(String sidocode) {
		List<GugunCodeDto> gugunlist = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			conn = util.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append(" Select code,name,sido_code from gugun_code\n").append(" where sido_code= ? \n");

			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, sidocode);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				GugunCodeDto gugunCodeDto = new GugunCodeDto();
				System.out.println(rs.getString("name"));
				gugunCodeDto.setCode(rs.getString("code"));
				gugunCodeDto.setName(rs.getString("name"));
				gugunCodeDto.setSidoCode(sidocode);
				gugunlist.add(gugunCodeDto);
				System.out.println(gugunCodeDto.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return gugunlist;
	}

	@Override
	public List<DongCodeDto> getDong(String guguncode) {
		List<DongCodeDto> donglist = new ArrayList<DongCodeDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			conn = util.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append(" Select code ,name,city_code,city_name, gugun_code, gugun_name from dong_code\n")
					.append(" where gugun_code= ? \n");

			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, guguncode);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				DongCodeDto dongCodeDto = new DongCodeDto();
				dongCodeDto.setCode(rs.getString("code"));
				dongCodeDto.setName(rs.getString("name"));
				dongCodeDto.setCityCode(rs.getString("city_code"));
				dongCodeDto.setCityName(rs.getString("city_name"));
				dongCodeDto.setGuguncode(guguncode);
				dongCodeDto.setGugunName(rs.getString("gugun_name"));
				donglist.add(dongCodeDto);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return donglist;
	}

	@Override
	public List<MainDto> mainList(String dongname, String guguncode) {
		List<MainDto> mainlist = new ArrayList<MainDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		System.out.println(dongname);

		try {

			conn = util.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select d.dong, d.aptname, d.code, d.dealamount, d.dealyear, d.dealmonth, i.lat, i.lng \n")
			.append("  from housedeal d join houseinfo i \n")
			.append("on i.jibun=d.jibun \n")
			.append("where d.code=? and d.dong=? and d.dealyear=?\n")
			.append("limit 15 \n");

			pstmt = conn.prepareStatement(sql.toString());
//			
			
			System.out.println(guguncode);
			System.out.println(dongname);
			pstmt.setString(1, guguncode);
			pstmt.setString(2, dongname);
			pstmt.setString(3, "2019");

			rs = pstmt.executeQuery();
			while (rs.next()) {
				MainDto mainDto = new MainDto();
				mainDto.setDong(dongname);
				mainDto.setAptname(rs.getString("aptname").trim());
				mainDto.setCode(guguncode);
				mainDto.setDealamount(rs.getString("dealamount").trim());
				mainDto.setDealyear(rs.getString("dealyear").trim());
				mainDto.setDealmonth(rs.getString("dealmonth").trim());
				mainDto.setLat(rs.getString("lat").trim());
				mainDto.setLng(rs.getString("lng").trim());
				mainlist.add(mainDto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}

		return mainlist;
	}

}
