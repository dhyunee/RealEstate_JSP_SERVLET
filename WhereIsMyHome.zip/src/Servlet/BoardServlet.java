package Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import Dto.BoardDto;
import Dto.UserDto;
import Service.BoardService;
import Service.BoardServiceImpl;

@WebServlet("/board/*")
public class BoardServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	BoardService service = BoardServiceImpl.getInstance();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
			
		HttpSession session = request.getSession();
		UserDto userDto = (UserDto) session.getAttribute("userDto");
		 
		String contextPath = request.getContextPath();
		String path = request.getRequestURI().substring( contextPath.length());
		System.out.println(path);
		
		switch(path) {
		case "/board/boardMain" : boardMain(request, response); break;
		// 게시판의 다른 기능
		case "/board/boardInsert" : boardInsert(request, response); break;
		case "/board/boardList" : boardList(request, response); break;
		case "/board/boardDetail" : boardDetail(request, response); break;
		case "/board/boardDelete" : boardUpdate(request, response); break;
		case "/board/boardUpdate" : boardDelete(request, response); break;
		}
	}

	private void boardUpdate(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		int boardId = Integer.parseInt(request.getParameter("boardId"));

		int userSeq = ((UserDto) request.getSession().getAttribute("userDto")).getUserSeq();
		
		BoardDto boardDto = new BoardDto();
		boardDto.setBoardId(boardId);
		boardDto.setTitle(title);
		boardDto.setContent(content);
		
		int ret = service.boardUpdate(boardDto);
		
		 Gson gson = new Gson();
         JsonObject jsonObject = new JsonObject();
         
         if(ret == 1) {
        	 jsonObject.addProperty("result","success");
         }else {
        	 jsonObject.addProperty("result","fail");
         }
         String jsonStr = gson.toJson(jsonObject);
         response.getWriter().write(jsonStr);
		
	}

	private void boardDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int boardId = Integer.parseInt(request.getParameter("boardId"));

		int ret = service.boardDelete(boardId);
		
		 Gson gson = new Gson();
         JsonObject jsonObject = new JsonObject();
         
         if(ret == 1) {
        	 jsonObject.addProperty("result","success");
         }else {
        	 jsonObject.addProperty("result","fail");
         }
         String jsonStr = gson.toJson(jsonObject);
         response.getWriter().write(jsonStr);

		
		
	}

	private void boardDetail(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		int boardId = Integer.parseInt(request.getParameter("boardId"));
		
		HttpSession session = request.getSession();
		UserDto userDto = (UserDto) session.getAttribute("userDto");
		int userSeq = userDto.getUserSeq();
		
		BoardDto boardDto = service.boardDetail(boardId, userSeq);
		
		 Gson gson = new Gson();
         String jsonStr = gson.toJson(boardDto, BoardDto.class); // 보다 명확한 표현
         System.out.println(jsonStr);
         response.getWriter().write(jsonStr);
	}


	private void boardInsert(HttpServletRequest request, HttpServletResponse response) throws IOException {

		String title = request.getParameter("title");
		String content = request.getParameter("content");

		
//		int ret = service.boardInsert(new BoardDto(userSeq, title, content));
		BoardDto boardDto = new BoardDto();
		boardDto.setTitle(title);
		boardDto.setContent(content);
		int ret = service.boardInsert(boardDto);
		
		 Gson gson = new Gson();
         JsonObject jsonObject = new JsonObject();
         
         if(ret == 1) {
        	 jsonObject.addProperty("result","success");
         }else {
        	 jsonObject.addProperty("result","fail");
         }
         String jsonStr = gson.toJson(jsonObject);
         response.getWriter().write(jsonStr);
		
	}
	
	private void boardList(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 파라미터 => limit, offset
		// limit, offset과 같은 UI와 관련된 항목들은 FRONT_END의 결정사항
		
		String strlimit = request.getParameter("limit");
		String strOffset = request.getParameter("offset");
		
		int limit = Integer.parseInt(strlimit);
		int offset = Integer.parseInt(strOffset);
		List<BoardDto> boardList = service.boardList(limit, offset);
		
		
		 Gson gson = new Gson();
         String jsonStr = gson.toJson(boardList);
         System.out.println(jsonStr);
         response.getWriter().write(jsonStr);
		
	}

	private void boardMain(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("/board.jsp");
		dispatcher.forward(request, response);
		
	}

}
