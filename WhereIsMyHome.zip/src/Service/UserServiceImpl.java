package Service;

import Dao.UserDao;
import Dao.UserDaoImpl;
import Dto.UserDto;
import Service.UserServiceImpl;

public class UserServiceImpl implements UserService {

	private static UserServiceImpl instance = new UserServiceImpl();

	private UserServiceImpl() {

	}

	public static UserServiceImpl getInstance() {
		return instance;
	}

	UserDao userDao = UserDaoImpl.getInstance();// member

	@Override
	public int userRegister(UserDto userDto) {

			return userDao.userRegister(userDto);
		}

	@Override
	public int deleteUser(UserDto userDto) {
		// TODO Auto-generated method stub
		return userDao.deleteUser(userDto);
	}

	@Override
	public int userUpdate(UserDto userDto) {
		// TODO Auto-generated method stub
		return userDao.userUpdate(userDto);
	}
	}

