package Service;

import java.util.List;

import Dao.BoardDao;
import Dao.BoardDaoImpl;
import Dto.BoardDto;

public class BoardServiceImpl implements BoardService{

	private static BoardServiceImpl instance = new BoardServiceImpl();
	
	private BoardServiceImpl() {}
	
	public static BoardServiceImpl getInstance() {
		return instance;
	}
	
	BoardDao dao = BoardDaoImpl.getInstance();
	
	@Override
	public int boardInsert(BoardDto dto) {
		return dao.boardInsert(dto);
	}

	@Override
	public List<BoardDto> boardList(int limit, int offset) {
		return dao.boardList(limit, offset);
	}



	@Override
	public BoardDto boardDetail(int boardId, int userSeq) { // userSeq는 현재 boardId게시물을 클릭한 사용자의 userSeq
		// TODO Auto-generated method stub
		BoardDto boardDto =  dao.boardDetail(boardId); // 게시글 정보, 이곳의 userSeq는 글 작성자의 userSeq
		// 두 사용자가 같은 지에 대한 sameUser 처리
		if(boardDto.getUserSeq() == userSeq) {
			boardDto.setSameUser(true);
		}else {
			boardDto.setSameUser(false);
		}
		
		return boardDto;
	}

	@Override
	public int boardDelete(int boardId) {
		return dao.boardDelete(boardId);
	}

	@Override
	public int boardUpdate(BoardDto dto) {
		return dao.boardUpdate(dto);
	}


}
