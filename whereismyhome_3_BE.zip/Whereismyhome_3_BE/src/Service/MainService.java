package Service;

public interface MainService {

}
