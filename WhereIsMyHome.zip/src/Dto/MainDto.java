package Dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;


public class MainDto {

	//house deal
	private String dong,aptname,code,dealamount,dealyear,dealmonth,lat,lng;

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLng() {
		return lng;
	}

	public void setLng(String lng) {
		this.lng = lng;
	}

	public String getDong() {
		return dong;
	}

	public void setDong(String dong) {
		this.dong = dong;
	}

	public String getAptname() {
		return aptname;
	}

	public void setAptname(String aptname) {
		this.aptname = aptname;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDealamount() {
		return dealamount;
	}

	public void setDealamount(String dealamount) {
		this.dealamount = dealamount;
	}

	public String getDealyear() {
		return dealyear;
	}

	public void setDealyear(String dealyear) {
		this.dealyear = dealyear;
	}

	public String getDealmonth() {
		return dealmonth;
	}

	public void setDealmonth(String dealmonth) {
		this.dealmonth = dealmonth;
	}

	@Override
	public String toString() {
		return "MainDto [dong=" + dong + ", aptname=" + aptname + ", code=" + code + ", dealamount=" + dealamount
				+ ", dealyear=" + dealyear + ", dealmonth=" + dealmonth + ",lat="+lat+",lng="+lng+ "]";
	}
	
	
	
}